package Modelo;

public interface Validar {
    public int Usuario(Usuario usuario);
}